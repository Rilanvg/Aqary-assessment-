-- query.sql

CREATE TABLE Seat (
    id INT PRIMARY KEY,                                                              student VARCHAR(255)
);

SELECT
    CASE
        WHEN id % 2 = 1 AND id = total_rows THEN id
        WHEN id % 2 = 1 THEN id + 1
        ELSE id - 1
    END AS id,
    student
FROM
    Seat
JOIN (
    SELECT
        COUNT(*) AS total_rows
    FROM
        Seat
) AS total ON 1 = 1
ORDER BY
    id;


-- Insert sample data into the Seat table
INSERT INTO Seat (id, student) VALUES (1, 'Abbot');
INSERT INTO Seat (id, student) VALUES (2, 'Doris');
INSERT INTO Seat (id, student) VALUES (3, 'Emerson');
INSERT INTO Seat (id, student) VALUES (4, 'Green');
INSERT INTO Seat (id, student) VALUES (5, 'Jeames');


SELECT * FROM Seat;