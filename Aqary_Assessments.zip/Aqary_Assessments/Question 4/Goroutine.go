package main

import (
	"fmt"
	"sync"
	"time"
)

const bufferSize = 10

func main() {
	// Scenario 1: M = 8, N = 2
	goReadWrite(8, 2)

	// Scenario 2: M = 8, N = 8
	goReadWrite(8, 8)

	// Scenario 3: M = 8, N = 16
	goReadWrite(8, 16)

	// Scenario 4: M = 2, N = 8
	goReadWrite(2, 8)

	// Sleep to allow goroutines to finish
	time.Sleep(time.Second * 5)
}

func goReadWrite(M, N int) {
	var (
		buffer   []byte
		readCh   = make(chan []byte)
		writeCh  = make(chan byte)
		readDone = make(chan struct{})
		writeDone = make(chan struct{})
		mutex    sync.Mutex
	)

	// Writers
	for i := 0; i < N; i++ {
		go func(id int) {
			for {
				select {
				case data := <-writeCh:
					mutex.Lock()
					buffer = append(buffer, data)
					fmt.Printf("Writer %d wrote: %c\n", id, data)
					mutex.Unlock()
				case <-writeDone:
					return
				}
			}
		}(i)
	}

	// Readers
	for i := 0; i < M; i++ {
		go func(id int) {
			for {
				select {
				case <-readCh:
					mutex.Lock()
					if len(buffer) > 0 {
						data := buffer[0]
						buffer = buffer[1:]
						fmt.Printf("Reader %d read: %c\n", id, data)
					}
					mutex.Unlock()
				case <-readDone:
					return
				}
			}
		}(i)
	}

	// Simulate read and write operations
	for i := 0; i < 10; i++ {
		writeCh <- byte('A' + i%26)
		readCh <- buffer
		time.Sleep(time.Millisecond * 100)
	}

	// Close channels to signal goroutines to finish
	close(writeDone)
	close(readDone)
}
