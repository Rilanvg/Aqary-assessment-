package main

import (
	"fmt"
	"sort"
)

func reorganizeString(s string) string {
	// Count the frequency of each character
	freqMap := make(map[rune]int)
	for _, char := range s {
		freqMap[char]++
	}

	// Create a slice of characters sorted by frequency
	var charFreqs []CharFreq
	for char, freq := range freqMap {
		charFreqs = append(charFreqs, CharFreq{char, freq})
	}
	sort.Sort(ByFrequency(charFreqs))

	// Construct the rearranged string
	result := make([]rune, len(s))
	index := 0
	for _, cf := range charFreqs {
		for i := 0; i < cf.Frequency; i++ {
			result[index] = cf.Char
			index += 2
			if index >= len(s) {
				index = 1
			}
		}
	}

	// Check if the rearrangement is valid
	for i := 1; i < len(result); i++ {
		if result[i] == result[i-1] {
			return ""
		}
	}

	return string(result)
}

// CharFreq represents a character and its frequency
type CharFreq struct {
	Char      rune
	Frequency int
}

// ByFrequency is used to sort CharFreq by frequency in descending order
type ByFrequency []CharFreq

func (a ByFrequency) Len() int           { return len(a) }
func (a ByFrequency) Swap(i, j int)      { a[i], a[j] = a[j], a[i] }
func (a ByFrequency) Less(i, j int) bool { return a[i].Frequency > a[j].Frequency }

func main() {
	fmt.Println(reorganizeString("aab"))   // Output: "aba"
	fmt.Println(reorganizeString("aaab"))  // Output: ""
	fmt.Println(reorganizeString("aabbcc")) // Output: "abcabc" or any valid rearrangement
}
